local ParentalControls =
{
	Name = "ParentalControls",
	Type = "System",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(ParentalControls);