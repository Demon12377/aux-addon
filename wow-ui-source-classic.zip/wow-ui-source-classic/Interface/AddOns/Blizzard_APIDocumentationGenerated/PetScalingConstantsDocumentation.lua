local PetScalingConstants =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(PetScalingConstants);