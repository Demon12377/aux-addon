local SharedTraitsEnums =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(SharedTraitsEnums);