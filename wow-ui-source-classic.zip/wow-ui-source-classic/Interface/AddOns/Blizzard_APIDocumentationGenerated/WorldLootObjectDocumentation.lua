local WorldLootObject =
{
	Name = "WorldLootObject",
	Type = "System",
	Namespace = "C_WorldLootObject",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(WorldLootObject);