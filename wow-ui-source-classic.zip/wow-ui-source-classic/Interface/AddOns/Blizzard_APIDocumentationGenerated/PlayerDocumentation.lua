local Player =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Player);