local SpellConstants =
{
	Tables =
	{
		{
			Name = "SpellCooldownConsts",
			Type = "Constants",
			Values =
			{
				{ Name = "GLOBAL_RECOVERY_CATEGORY", Type = "number", Value = 133 },
			},
		},
	},
};

APIDocumentation:AddDocumentationTable(SpellConstants);