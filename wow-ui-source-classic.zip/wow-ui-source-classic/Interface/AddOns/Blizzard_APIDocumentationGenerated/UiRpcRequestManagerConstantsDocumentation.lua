local UiRpcRequestManagerConstants =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(UiRpcRequestManagerConstants);