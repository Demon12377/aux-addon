local Color =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Color);