local UIFileAssetShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(UIFileAssetShared);