local SystemTime =
{
	Name = "SystemTime",
	Type = "System",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(SystemTime);