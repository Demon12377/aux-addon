local QuestConstants_Classic =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(QuestConstants_Classic);