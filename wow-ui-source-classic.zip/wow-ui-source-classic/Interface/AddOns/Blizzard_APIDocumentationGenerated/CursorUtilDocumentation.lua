local CursorUtil =
{
	Name = "CursorUtil",
	Type = "System",
	Namespace = "C_CursorUtil",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(CursorUtil);