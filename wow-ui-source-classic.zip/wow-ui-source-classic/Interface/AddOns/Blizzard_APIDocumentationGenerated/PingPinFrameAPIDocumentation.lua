local PingPinFrameAPI =
{
	Name = "PingPinFrameAPI",
	Type = "ScriptObject",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(PingPinFrameAPI);