local TalentAndGlyphConstants =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(TalentAndGlyphConstants);