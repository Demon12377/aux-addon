local SimpleMaskTextureAPI =
{
	Name = "SimpleMaskTextureAPI",
	Type = "ScriptObject",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(SimpleMaskTextureAPI);