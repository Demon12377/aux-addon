local PingManager =
{
	Name = "PingManager",
	Type = "System",
	Namespace = "C_Ping",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(PingManager);