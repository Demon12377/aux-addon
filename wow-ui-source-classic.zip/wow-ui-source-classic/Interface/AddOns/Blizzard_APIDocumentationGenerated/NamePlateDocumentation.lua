local NamePlate =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(NamePlate);