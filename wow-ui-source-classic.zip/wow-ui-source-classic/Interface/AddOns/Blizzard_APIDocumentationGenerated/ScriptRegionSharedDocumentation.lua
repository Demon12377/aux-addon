local ScriptRegionShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(ScriptRegionShared);