local VectorShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(VectorShared);