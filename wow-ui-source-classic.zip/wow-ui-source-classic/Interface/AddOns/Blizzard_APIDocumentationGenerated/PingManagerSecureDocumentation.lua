local PingManagerSecure =
{
	Name = "PingManagerSecure",
	Type = "System",
	Namespace = "C_PingSecure",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(PingManagerSecure);