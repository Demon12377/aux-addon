local Base =
{
	Tables =
	{
		{
			Name = "ScriptObject",
			Type = "Structure",
			Fields =
			{
			},
		},
	},
};

APIDocumentation:AddDocumentationTable(Base);