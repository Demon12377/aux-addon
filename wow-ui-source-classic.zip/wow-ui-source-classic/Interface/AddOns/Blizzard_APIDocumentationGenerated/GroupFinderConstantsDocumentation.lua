local GroupFinderConstants =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(GroupFinderConstants);