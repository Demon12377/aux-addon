local Portrait =
{
	Name = "Portrait",
	Type = "System",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Portrait);