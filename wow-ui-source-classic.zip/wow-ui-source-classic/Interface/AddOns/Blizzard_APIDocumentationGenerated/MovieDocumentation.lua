local Movie =
{
	Name = "Movie",
	Type = "System",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Movie);