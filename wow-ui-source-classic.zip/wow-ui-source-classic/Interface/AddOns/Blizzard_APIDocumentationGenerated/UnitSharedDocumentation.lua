local UnitShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(UnitShared);