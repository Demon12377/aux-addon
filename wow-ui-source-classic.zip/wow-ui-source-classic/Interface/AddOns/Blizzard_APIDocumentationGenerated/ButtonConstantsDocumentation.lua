local ButtonConstants =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(ButtonConstants);