local AuctionHouseConstants_Classic =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(AuctionHouseConstants_Classic);