local WeeklyRewardsShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(WeeklyRewardsShared);