local TraitConfig =
{
	Name = "TraitConfig",
	Type = "System",
	Namespace = "C_TraitConfig",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(TraitConfig);