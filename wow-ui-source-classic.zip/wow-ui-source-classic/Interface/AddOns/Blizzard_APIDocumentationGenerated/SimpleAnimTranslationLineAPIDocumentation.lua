local SimpleAnimTranslationLineAPI =
{
	Name = "SimpleAnimTranslationLineAPI",
	Type = "ScriptObject",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(SimpleAnimTranslationLineAPI);