local FrameAPIArchaeologyDigsite =
{
	Name = "FrameAPIArchaeologyDigSiteFrame",
	Type = "ScriptObject",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(FrameAPIArchaeologyDigsite);