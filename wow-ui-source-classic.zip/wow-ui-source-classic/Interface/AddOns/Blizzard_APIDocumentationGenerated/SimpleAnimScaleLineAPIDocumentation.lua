local SimpleAnimScaleLineAPI =
{
	Name = "SimpleAnimScaleLineAPI",
	Type = "ScriptObject",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(SimpleAnimScaleLineAPI);