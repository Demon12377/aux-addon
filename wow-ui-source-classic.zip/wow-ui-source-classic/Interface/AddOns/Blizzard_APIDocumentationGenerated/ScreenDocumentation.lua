local Screen =
{
	Name = "Screen",
	Type = "System",

	Functions =
	{
	},

	Events =
	{
	},

	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Screen);