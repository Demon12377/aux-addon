local UITextureAssetShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(UITextureAssetShared);