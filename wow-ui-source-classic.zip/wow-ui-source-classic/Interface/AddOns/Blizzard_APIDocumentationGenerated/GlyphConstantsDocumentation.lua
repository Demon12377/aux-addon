local GlyphConstants =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(GlyphConstants);